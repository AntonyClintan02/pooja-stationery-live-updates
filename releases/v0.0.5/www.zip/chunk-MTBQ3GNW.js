import{a,b}from"./chunk-U5Q47F2O.js";import"./chunk-OS2SO5SL.js";b();export{a as startFocusVisible};
