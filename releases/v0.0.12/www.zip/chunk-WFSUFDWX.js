import{d as e}from"./chunk-TPQPHERT.js";var o=e("BarcodeScanner",{web:()=>import("./chunk-VR7SXLFD.js").then(r=>new r.BarcodeScannerWeb)});export{o as a};
