import{a,b}from"./chunk-AYYYEQID.js";import"./chunk-OS2SO5SL.js";b();export{a as startFocusVisible};
