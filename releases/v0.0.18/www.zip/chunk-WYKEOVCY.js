import{d as p}from"./chunk-TPQPHERT.js";var o=p("App",{web:()=>import("./chunk-6KCT2CTO.js").then(e=>new e.AppWeb)});export{o as a};
