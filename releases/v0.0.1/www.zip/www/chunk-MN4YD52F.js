import{a as b,b as c}from"./chunk-D5W22C2B.js";import{b as a}from"./chunk-S3RZIDZZ.js";import"./chunk-OS2SO5SL.js";c();export{a as GESTURE_CONTROLLER,b as createGesture};
