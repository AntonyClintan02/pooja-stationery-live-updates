import{a}from"./chunk-7KGURMOZ.js";import"./chunk-VBFW7A5V.js";export{a as startFocusVisible};
