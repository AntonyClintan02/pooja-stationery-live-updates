import{f as e}from"./chunk-OS2SO5SL.js";var o,i=e(()=>{"use strict";o=r=>r&&r.dir!==""?r.dir.toLowerCase()==="rtl":document?.dir.toLowerCase()==="rtl"});export{o as a,i as b};
