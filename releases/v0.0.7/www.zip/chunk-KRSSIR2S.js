import{f as n}from"./chunk-OS2SO5SL.js";var e,o,d=n(()=>{"use strict";e=typeof window<"u"?window:void 0,o=typeof document<"u"?document:void 0});export{e as a,o as b,d as c};
