import{a as r,c as n}from"./chunk-OE5PMDKG.js";import{f as e}from"./chunk-OS2SO5SL.js";var a,t=e(()=>{"use strict";n();a=()=>{if(r!==void 0)return r.Capacitor}});export{a,t as b};
