import{b as a,d as b,e as c}from"./chunk-6PPCSNOQ.js";import"./chunk-OS2SO5SL.js";c();export{a as GESTURE_CONTROLLER,b as createGesture};
